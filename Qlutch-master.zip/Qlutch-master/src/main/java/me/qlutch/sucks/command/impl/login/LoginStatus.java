/*
 * Decompiled with CFR 0.152.
 */
package me.qlutch.sucks.command.impl.login;

public enum LoginStatus {
    SUSPENDED,
    ADMIN,
    PREMIUM,
    LITE,
    FREE;
}

