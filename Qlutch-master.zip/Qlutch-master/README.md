# Qlutch Force Op

Qlutch is a "Advanced Minecraft Force Op" developed by me a "13 year old kid who doesnt know java" and sold to the public for 5 years scamming everyone who bought it and tricking them into thinking it can do stuff that it cannot.

### Why Am I Releasing?
I stoped development because I relized how dumb this project sounds. A "Advanced" backdoor for a block game only played by 10 year olds.
Another reason is that I cannot keep up with the amazing talent of other developers who have made backdoors 10x better then mine (ec. Kego made by Python) for these tools had uniqe injectors that I do not know how to make.

### Info
This project was very poorly coded and some code might not work not because "we" had to deobfuscate it or anything but because im very bad at coding.
If you would like to contribute to fix the code you can be my guest but I will not take suggestions for commands for I do not want to work on this anymore.

Make sure to join Pythons amazing server to https://discord.gg/4Sy9kjHkEr

Also Check out awesome new video https://www.youtube.com/watch?v=6ISkPi_nVIA&t=3s

## Credit
Python (Being amazing and fixing my issue's)\
CeMrK (Hes just a sexy mf)\
Abhi (My idol)\
Me also known as !AmANoot (copying and pasting)

